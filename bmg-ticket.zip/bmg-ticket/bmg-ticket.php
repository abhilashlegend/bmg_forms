<?php
/**
 * @package Bmg ticket
 */
/*
Plugin Name: Bmg ticket
Description: Allow users to submit ticket in admin panel
Version: 1.0.0
Author: Abhilash
License: GPLv2 or later
Text Domain: bmg-ticket
*/

include( plugin_dir_path( __FILE__ ) . 'includes/menus.php');
include( plugin_dir_path( __FILE__) . 'includes/settings.php'); 
include( plugin_dir_path( __FILE__) . 'includes/enqueue.php');
?>