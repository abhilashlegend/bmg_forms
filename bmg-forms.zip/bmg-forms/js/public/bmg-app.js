jQuery(document).ready(function(){
tinymce.init({
    selector: '.tinymce-enabled'
  });
});