<div class="wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e( get_admin_page_title() ); ?></h1>
	<div id="titlediv">
		<div id="titlewrap">
				<label class="screen-reader-text" id="title-prompt-text" for="title">Enter form name</label>
			<input type="text" name="post_title" class="bmg-forms-new-form" value="" id="bmg-form-name" spellcheck="true" autocomplete="off" placeholder="Enter Form Name">
		</div>
	</div>
	<div id="bmg-forms-build-wrap">
		
	</div>
	<div class="saveDataWrap">
  <button id="saveData" type="button">Generate Form</button>
</div>
</div>
